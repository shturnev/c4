-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.13 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.4.0.5151
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица e_shop_c4.basket
CREATE TABLE IF NOT EXISTS `basket` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL DEFAULT '0',
  `date_of_add` int(5) NOT NULL DEFAULT '0',
  `units` int(5) NOT NULL DEFAULT '0',
  `price` varchar(50) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '0',
  `status` varchar(50) NOT NULL DEFAULT 'wait' COMMENT 'finished',
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `FK_basket_users` (`user_id`),
  KEY `FK_basket_products` (`product_id`),
  CONSTRAINT `FK_basket_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_basket_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='корзина';

-- Дамп данных таблицы e_shop_c4.basket: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `basket` DISABLE KEYS */;
INSERT IGNORE INTO `basket` (`ID`, `product_id`, `date_of_add`, `units`, `price`, `ip`, `status`, `user_id`) VALUES
	(5, 6, 1494867382, 1, '1111', '127.0.0.1', 'wait', 9),
	(6, 5, 1494867385, 1, 'выавыавы', '127.0.0.1', 'wait', 9);
/*!40000 ALTER TABLE `basket` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '0',
  `nomer` int(6) DEFAULT '0',
  `logo` varchar(220) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.brands: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT IGNORE INTO `brands` (`ID`, `name`, `nomer`, `logo`) VALUES
	(1, 'adidas3', 1, '149339480926649.png'),
	(6, 'выавыа выа', 3, '149382469527925.png'),
	(7, 'выавыа выа ыва ыва', 1, '149339787921183.png'),
	(8, 'sdsdsd', 0, '149382460932221.png');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `nomer` int(5) NOT NULL DEFAULT '0',
  `text` text,
  `photo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.categories: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT IGNORE INTO `categories` (`ID`, `name`, `nomer`, `text`, `photo`) VALUES
	(1, 'Kids', 3, NULL, NULL),
	(3, 'Men', 1, NULL, '1494603377897.png'),
	(4, 'Women', 0, NULL, '149460437831782.jpg'),
	(5, 'Accessories', 4, NULL, NULL),
	(6, 'Shoes', 2, NULL, NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.gallery
CREATE TABLE IF NOT EXISTS `gallery` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL DEFAULT '0',
  `table_name` varchar(250) NOT NULL DEFAULT '0',
  `table_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.gallery: ~15 rows (приблизительно)
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
INSERT IGNORE INTO `gallery` (`ID`, `name`, `table_name`, `table_id`) VALUES
	(1, '149442920232278.jpg', 'products', 3),
	(2, '14944292025015.jpg', 'products', 3),
	(3, '14944292022436.jpg', 'products', 3),
	(4, '149442920230061.jpg', 'products', 3),
	(5, '149443329723844.jpg', 'products', 4),
	(6, '149443329720621.jpg', 'products', 4),
	(7, '149443329729250.jpg', 'products', 4),
	(8, '149443332429267.jpg', 'products', 5),
	(9, '149443332410128.jpg', 'products', 5),
	(10, '149443332426761.jpg', 'products', 5),
	(11, '149443332428814.jpg', 'products', 5),
	(12, '149443332424751.jpg', 'products', 5),
	(13, '14946073118295.jpg', 'products', 6),
	(14, '149460731124084.jpg', 'products', 6),
	(15, '149460731122205.jpg', 'products', 6);
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT '0',
  `email` varchar(200) NOT NULL DEFAULT '0',
  `subject` varchar(200) DEFAULT '0',
  `text` text NOT NULL,
  `ip` varchar(200) NOT NULL DEFAULT '0',
  `date` bigint(12) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.messages: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT IGNORE INTO `messages` (`ID`, `name`, `email`, `subject`, `text`, `ip`, `date`, `status`) VALUES
	(1, 'asdasdasd', 'sht_job@ukr.net', 'sadasdasd', 'sdasd\r\nsad\r\nasd\r\n\r\nasd', '127.0.0.1', 1495211961, 1),
	(2, 'asdasd', 'sht_job@ukr.net', 'dasdasdasd', 'asdasdas asd asd \r\nsad\r\n\r\nsd\r\nasdasd', '127.0.0.1', 1495213494, 1),
	(3, 'sdasdasdasd', 'sht_job@ukr.net', 'dasdasdasd', 'The icon font weighs in at only 42KB in its smallest woff2 format and 56KB in standard woff format. By comparison, the SVG files compressed with gzip will generally be around 62KB in size, but this can be reduced considerably by compiling only the icons you need into a single SVG file with symbol sprites.\r\n\r\nSetup Method 1. Using via Google Web Fonts\r\n\r\nThe easiest way to set up icon fonts for use in any web page is through Google Web Fonts. All you need to do is include a single line of HTML:\r\n\r\n&lt;link href=&quot;https://fonts.googleapis.com/icon?family', '127.0.0.1', 1495213522, 1);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.page_settings
CREATE TABLE IF NOT EXISTS `page_settings` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `stranica` varchar(250) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `meta_title` varchar(250) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_descr` varchar(250) DEFAULT NULL,
  `btn_title` varchar(250) DEFAULT NULL,
  `photo` varchar(250) DEFAULT NULL,
  `text` text,
  `other_info` json DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stranica` (`stranica`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='настройки для наших страниц';

-- Дамп данных таблицы e_shop_c4.page_settings: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `page_settings` DISABLE KEYS */;
INSERT IGNORE INTO `page_settings` (`ID`, `stranica`, `title`, `meta_title`, `meta_key`, `meta_descr`, `btn_title`, `photo`, `text`, `other_info`) VALUES
	(1, 'index', 'Главная страница', 'Главная страница', 'ывыв', 'ывфывфы', 'home', '149503923727895.jpg', '<p>homesd sd asd asd asd asd asd asd asd sa&nbsp;</p>', 'null'),
	(4, 'contact', 'Контактная информация', 'Контактная информация', 'вав ава в', 'а ва ва ва', 'Contact', '', '<p>Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas.At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas.</p>\r\n\r\n<p>&nbsp;</p>', '{"map": "<iframe src=\\"https://api-maps.yandex.ua/frame/v1/-/CZh2MR78\\" width=\\"560\\" height=\\"400\\" frameborder=\\"0\\"></iframe>", "email": "sht_jossdsdb@ukr.net", "hours": "Monday-Friday, 7AM-5PM", "phone": "+380808665556", "address": "Lorem ipsum dolor, TL 19034-88974"}'),
	(6, 'about', 'О нас', '', '', '', '', '', '<p>ывк выв ывыв ыв,ыв ы</p>\r\n\r\n<p>вы</p>\r\n\r\n<p>в&nbsp;</p>\r\n\r\n<p>ыв</p>\r\n\r\n<p>&nbsp;ы</p>\r\n\r\n<p>в ыв ыв ыв ыв ыв&nbsp;</p>', 'null');
/*!40000 ALTER TABLE `page_settings` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.products
CREATE TABLE IF NOT EXISTS `products` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `brand_id` int(5) NOT NULL DEFAULT '0',
  `type_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '0',
  `price` varchar(250) DEFAULT '0',
  `descr_1` text COMMENT 'QUICK OVERVIEW',
  `descr_2` text COMMENT 'основное описание',
  `descr_3` text COMMENT 'дополнительная информация',
  `meta_title` varchar(250) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_descr` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.products: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT IGNORE INTO `products` (`ID`, `cat_id`, `brand_id`, `type_id`, `title`, `price`, `descr_1`, `descr_2`, `descr_3`, `meta_title`, `meta_key`, `meta_descr`) VALUES
	(1, 4, 8, 0, '11111', '232323', '<p>dsdasd asdas dsad&nbsp;</p><p>asd sad asd asd&nbsp;</p>', '<p>fgdfg dfg dfg dfg dfg&nbsp;</p><p>df dsf dsf d111111111</p>', '<p>dsds sd sds22222222</p>', '222222222222', '344444444444', '333333333'),
	(2, 6, 1, 11, 'sdsdsdsds', '19', '<p>sadsa dasd asd&nbsp;</p>', '<p>asd asd asd&nbsp;</p>', '<p>sdf sdfsdf sdf&nbsp;</p>', 'erewrewrew', 'sdfdsfdf sdf dsf', 'dfsdfdsf'),
	(3, 6, 8, 11, 'sdsdsdsds', '19', '<p>sadsa dasd asd&nbsp;</p>', '<p>asd asd asd&nbsp;</p>', '<p>sdf sdfsdf sdf&nbsp;</p>', 'erewrewrew', 'sdfdsfdf sdf dsf', 'dfsdfdsf'),
	(4, 6, 8, 11, 'dfgdfgdfg', 'dfgdfgdfg', '<p>dfgdf dfg dfg dfg&nbsp;</p>', '<p>dfg dfg dfg dfgdf</p>', '<p>dfg dfg dfg dfg&nbsp;</p>', 'fdsfdsfds', 'dsfdsfdsf', 'fdsfdsf'),
	(5, 5, 8, 8, 'вавыа', 'выавыавы', '<p>авыавыавыавыа</p>', '<p>выавыа</p>', '<p>выавыа</p>', 'выаы', 'авыа', 'авыавы'),
	(6, 4, 8, 13, '111111', '1111', '<p>sdsadasd</p>', '<p>asdasdasd</p>', '<p>asdasdasdas</p>', '', '', '');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.types
CREATE TABLE IF NOT EXISTS `types` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '0',
  `nomer` int(5) NOT NULL DEFAULT '0',
  `text` text,
  `photo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_types_categories` (`cat_id`),
  CONSTRAINT `FK_types_categories` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.types: ~6 rows (приблизительно)
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT IGNORE INTO `types` (`ID`, `cat_id`, `name`, `nomer`, `text`, `photo`) VALUES
	(8, 5, 'Jeans', 0, NULL, NULL),
	(9, 6, 'Кроссовки', 2, NULL, NULL),
	(10, 6, 'Сандали', 1, NULL, NULL),
	(11, 6, 'Туфли', 0, NULL, NULL),
	(13, 4, 'Jeans', 0, NULL, NULL),
	(14, 4, 'Кепки', 0, NULL, NULL),
	(15, 4, 'Туфли', 0, NULL, NULL);
/*!40000 ALTER TABLE `types` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `pass` varchar(255) NOT NULL,
  `verify` int(2) NOT NULL DEFAULT '0',
  `admin` int(2) NOT NULL DEFAULT '0',
  `date` bigint(11) DEFAULT NULL,
  `token` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.users: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`ID`, `email`, `name`, `phone`, `pass`, `verify`, `admin`, `date`, `token`) VALUES
	(9, 'sht_job@ukr.net', 'Сергей Юрьевич Штурнев', '+380934669146', '$2y$10$xvD9TSo1rrU0004ytH4sM.w8G2DuwYhEq1T1NJX/Sg1ViJPvui0di', 1, 1, 1493050097, '0faea1d6bf75df6f0cc0bc0a4bdcf853');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
