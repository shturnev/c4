-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.13 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.4.0.5151
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица e_shop_c4.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '0',
  `nomer` int(6) DEFAULT '0',
  `logo` varchar(220) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.brands: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT IGNORE INTO `brands` (`ID`, `name`, `nomer`, `logo`) VALUES
	(1, 'adidas3', 1, '149339480926649.png'),
	(3, '0', 2, '0'),
	(6, 'выавыа выа', 3, '149382469527925.png'),
	(7, 'выавыа выа ыва ыва', 1, '149339787921183.png'),
	(8, 'sdsdsd', 0, '149382460932221.png');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `nomer` int(5) NOT NULL DEFAULT '0',
  `text` text,
  `photo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.categories: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT IGNORE INTO `categories` (`ID`, `name`, `nomer`, `text`, `photo`) VALUES
	(1, 'Kids', 1, NULL, NULL),
	(3, 'Men', 2, NULL, NULL),
	(4, 'Women', 0, NULL, NULL),
	(5, 'Accessories', 4, NULL, NULL),
	(6, 'Shoes', 0, NULL, NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.gallery
CREATE TABLE IF NOT EXISTS `gallery` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL DEFAULT '0',
  `table_name` varchar(250) NOT NULL DEFAULT '0',
  `table_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.gallery: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.products
CREATE TABLE IF NOT EXISTS `products` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `brand_id` int(5) NOT NULL DEFAULT '0',
  `type_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '0',
  `price` varchar(250) DEFAULT '0',
  `descr_1` text COMMENT 'QUICK OVERVIEW',
  `descr_2` text COMMENT 'основное описание',
  `descr_3` text COMMENT 'дополнительная информация',
  `meta_title` varchar(250) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_descr` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.products: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT IGNORE INTO `products` (`ID`, `cat_id`, `brand_id`, `type_id`, `title`, `price`, `descr_1`, `descr_2`, `descr_3`, `meta_title`, `meta_key`, `meta_descr`) VALUES
	(1, 4, 8, 0, '11111', '232323', '<p>dsdasd asdas dsad&nbsp;</p><p>asd sad asd asd&nbsp;</p>', '<p>fgdfg dfg dfg dfg dfg&nbsp;</p><p>df dsf dsf d111111111</p>', '<p>dsds sd sds22222222</p>', '222222222222', '344444444444', '333333333');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.types
CREATE TABLE IF NOT EXISTS `types` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '0',
  `nomer` int(5) NOT NULL DEFAULT '0',
  `text` text,
  `photo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `name` (`name`),
  KEY `FK_types_categories` (`cat_id`),
  CONSTRAINT `FK_types_categories` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.types: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT IGNORE INTO `types` (`ID`, `cat_id`, `name`, `nomer`, `text`, `photo`) VALUES
	(8, 5, 'Jeans', 0, NULL, NULL),
	(9, 6, 'Кроссовки', 2, NULL, NULL),
	(10, 6, 'Сандали', 1, NULL, NULL),
	(11, 6, 'Туфли', 0, NULL, NULL);
/*!40000 ALTER TABLE `types` ENABLE KEYS */;

-- Дамп структуры для таблица e_shop_c4.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `pass` varchar(255) NOT NULL,
  `verify` int(2) NOT NULL DEFAULT '0',
  `admin` int(2) NOT NULL DEFAULT '0',
  `date` bigint(11) DEFAULT NULL,
  `token` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e_shop_c4.users: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`ID`, `email`, `name`, `phone`, `pass`, `verify`, `admin`, `date`, `token`) VALUES
	(9, 'sht_job@ukr.net', 'Сергей Юрьевич Штурнев', '+380934669146', '$2y$10$xvD9TSo1rrU0004ytH4sM.w8G2DuwYhEq1T1NJX/Sg1ViJPvui0di', 1, 1, 1493050097, '0faea1d6bf75df6f0cc0bc0a4bdcf853');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
