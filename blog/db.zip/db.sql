-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.13 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.4.0.5151
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица blog_c4.blog
CREATE TABLE IF NOT EXISTS `blog` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL DEFAULT '0',
  `descr` text,
  `text` text,
  `date` bigint(11) NOT NULL DEFAULT '0',
  `user_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `FK_blog_users` (`user_id`),
  CONSTRAINT `FK_blog_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы blog_c4.blog: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT IGNORE INTO `blog` (`ID`, `title`, `descr`, `text`, `date`, `user_id`) VALUES
	(4, 'Верстка из psd макета (практикуем с flexbox) maket #2 часть 3', '<p>zxcz s sd asd asd</p>\r\n', '<p>as dasd asd asd&nbsp;</p>\r\n', 1492187818, 4),
	(5, 'fdsfdsfdsfdsf', '<p>dfsdsfdsf</p>\r\n', '<p>dsfdsf</p>\r\n', 1492189129, 4),
	(6, 'fdsfdsfdsfdsfdsfdsf', '<p>dsfdsfdsf</p>\r\n', '<p>dsfdsfdsf</p>\r\n', 1492189137, 4),
	(7, '546546546', '<p>dfdsfdsfsdf</p>\r\n', '', 1492189144, 4),
	(8, 'hgfhgfhgfhgfh', '', '', 1492189149, 4),
	(9, '546546546546', '', '', 1492189154, 4),
	(10, 'w5345345345345345', '', '', 1492189160, 4),
	(11, '890890890878567546', '', '', 1492189166, 4);
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;

-- Дамп структуры для таблица blog_c4.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `verify` int(2) NOT NULL DEFAULT '0',
  `admin` int(2) NOT NULL DEFAULT '0',
  `date` bigint(11) DEFAULT NULL,
  `token` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы blog_c4.users: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`ID`, `email`, `pass`, `verify`, `admin`, `date`, `token`) VALUES
	(4, 'sht_job@ukr.net', '$2y$10$JUlsnfD27FVSYR7HrPufTuAT8hHx/L2QZkwxptyC7R/Fe1C0cxJ6G', 1, 1, 1492010198, '4bac62ac17b76d2c1fbe0c344d43878a');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
